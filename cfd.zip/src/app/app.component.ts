import { Component } from '@angular/core';
import { Console } from 'console';
import { User } from 'src/models/User';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'cfd';
  users: User[] = [];
  filteredUsers: { id: number, name: string, email:string }[] = [];
  selectedRow: number = -1;
  selectedValue:string = '';
  isDropdownOpen: boolean = false;
  isFilter:boolean = false;
  constructor() {
    this.users = [
      { id: 1, name: 'John Doe', email: 'johndoe@example.com' },
      { id: 2, name: 'Jane Smith', email: 'janesmith@example.com' },
      { id: 3, name: 'Bob Johnson', email: 'bobjohnson@example.com' },
      { id: 4, name: 'Alice Brown', email: 'alicebrown@example.com' },
      { id: 5, name: 'Mike Wilson', email: 'mikewilson@example.com' },
      { id: 6, name: 'Sarah Davis', email: 'sarahdavis@example.com' },
      { id: 7, name: 'Chris Thompson', email: 'christhompson@example.com' },
      { id: 8, name: 'Olivia Lee', email: 'olivialee@example.com' },
      { id: 9, name: 'Daniel Miller', email: 'danielmiller@example.com' },
      { id: 10, name: 'Emily Clark', email: 'emilyclark@example.com' }
    ];
  }

  selectRow(row: any) {
    this.selectedRow = row;
    this.isDropdownOpen = false;
    this.selectedValue = row.name;
    console.log('Selected row:', row,' :',this.isDropdownOpen);
  }

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
    console.log(this.isDropdownOpen);
  }

  getItems() {
    return this.isFilter ? this.filteredUsers : this.users;
  }

  onEventTrigger(event:Event){
    const value = (event.target as HTMLInputElement).value;
    console.log(value);
    if(value != null){
      this.filteredUsers = this.users.filter(user => user.name.toLowerCase().includes(value.toLowerCase())
      || user.email.toLowerCase().includes(value.toLowerCase()));
    }else{
      this.filteredUsers = this.users;
    }
    if(this.filteredUsers.length>0) this.isFilter = true;

    console.log(this.filteredUsers);
  }
}
